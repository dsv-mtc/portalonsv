import  'bootstrap/dist/css/bootstrap.css';
import 'owl.carousel/dist/assets/owl.carousel.css';
import '../css/all.css';
import '../css/main.css';
import '../css/main-media.css';
import 'bootstrap';
//import '../scss/_custom.scss'; //carga de todos los estilos scss
import 'owl.carousel';
import './main'; //carga de archivos js