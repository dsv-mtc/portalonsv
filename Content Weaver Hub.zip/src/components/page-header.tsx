import type { ReactNode } from "react";

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="mb-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="onsv-tab" aria-hidden>
            <span
              aria-hidden
              className="inline-block"
              style={{ width: 6, height: 24, background: "var(--brand-red)", borderRadius: 3 }}
            />
            {title}
          </span>
          {eyebrow ? <span className="onsv-eyebrow hidden sm:inline">{eyebrow}</span> : null}
        </div>
        {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
      </div>
      {description ? (
        <p className="mt-4 text-sm text-muted-foreground max-w-3xl leading-relaxed">{description}</p>
      ) : null}
    </header>
  );
}