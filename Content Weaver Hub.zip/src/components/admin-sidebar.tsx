import { useState } from "react";
import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard,
  PanelBottom,
  BarChart3,
  Map,
  Megaphone,
  Target,
  LineChart,
  Sparkles,
  Database,
  Users,
  ChevronDown,
  LogOut,
  Search,
  Command,
  PanelLeftClose,
  PanelLeft,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { OnsvLogo } from "@/components/onsv-logo";

type NavChild = { label: string; to: string; hash?: string };
type NavItem = {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  to?: string;
  children?: NavChild[];
  badge?: string;
};

const NAV: NavItem[] = [
  { label: "Inicio", icon: LayoutDashboard, to: "/admin" },
  { label: "Pie de página", icon: PanelBottom, to: "/admin/pie" },
  { label: "Cifras", icon: BarChart3, to: "/admin/cifras" },
  { label: "Regiones", icon: Map, to: "/admin/regiones" },
  { label: "Comunicaciones", icon: Megaphone, to: "/admin/comunicaciones" },
  { label: "Misión — Visión", icon: Target, to: "/admin/mision" },
  {
    label: "Analítica",
    icon: LineChart,
    children: [
      { label: "Menú", to: "/admin/analitica", hash: "menu" },
      { label: "Submenú", to: "/admin/analitica", hash: "submenu" },
    ],
  },
  { label: "Popup", icon: Sparkles, to: "/admin/popup" },
  {
    label: "Datos Abiertos",
    icon: Database,
    children: [
      { label: "Datos", to: "/admin/datos", hash: "datos" },
      { label: "Categorías", to: "/admin/datos", hash: "categorias" },
      { label: "Tipo", to: "/admin/datos", hash: "tipo" },
    ],
  },
  {
    label: "Gestión de Usuarios",
    icon: Users,
    children: [
      { label: "Usuarios", to: "/admin/usuarios", hash: "usuarios" },
      { label: "Roles", to: "/admin/usuarios", hash: "roles" },
    ],
  },
];

export function AdminSidebar({
  collapsed,
  onToggle,
  mobileOpen = false,
  onMobileClose,
}: {
  collapsed: boolean;
  onToggle: () => void;
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(NAV.filter((n) => n.children).map((n) => [n.label, true])),
  );

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <button
          type="button"
          aria-label="Cerrar menú"
          onClick={onMobileClose}
          className="lg:hidden fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
        />
      )}
      <aside
        className={cn(
          "text-[color:var(--sidebar-foreground)] flex flex-col",
          // Mobile: fixed off-canvas drawer
          "fixed inset-y-0 left-0 z-50 w-[280px] transform transition-transform duration-300 ease-out",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
          // Desktop: static, width-collapsible
          "lg:relative lg:translate-x-0 lg:z-auto lg:transition-[width] lg:shrink-0",
          collapsed ? "lg:w-[72px]" : "lg:w-[280px]",
        )}
        style={{
          background:
            "linear-gradient(180deg, #0d1730 0%, #101a34 55%, #0b1428 100%)",
          borderRight: "1px solid rgba(255,255,255,0.06)",
        }}
      >
      {/* Red seam accent — echoes the portal's red home cell */}
      <span
        aria-hidden
        className="absolute inset-y-0 right-0 w-[3px]"
        style={{ background: "linear-gradient(180deg,transparent, #C8102E 30%, #C8102E 70%, transparent)" }}
      />

      {/* Brand */}
      <div className="relative flex items-center gap-3 px-4 h-[72px] border-b border-white/5">
        <OnsvLogo className="w-11 h-11" tone="light" />
        {(!collapsed || mobileOpen) && (
          <div className="flex flex-col leading-none">
            <span
              className="text-[15px] font-extrabold uppercase tracking-tight text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Portal ONSV
            </span>
            <span
              className="text-[10px] font-bold tracking-[0.18em] uppercase mt-1"
              style={{ fontFamily: "var(--font-cond)", color: "#F4B41A" }}
            >
              Panel Administrativo
            </span>
          </div>
        )}
        {/* Mobile close button */}
        <button
          type="button"
          onClick={onMobileClose}
          aria-label="Cerrar menú"
          className="lg:hidden ml-auto w-9 h-9 rounded-lg grid place-items-center text-white/70 hover:text-white hover:bg-white/10 transition"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Search / ⌘K */}
      {(!collapsed || mobileOpen) && (
        <div className="px-4 pt-4">
          <button
            type="button"
            className="w-full group flex items-center gap-2 rounded-lg px-3 h-9 bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-[13px] text-white/60 transition"
            onClick={() => alert("Command palette (demo)")}
          >
            <Search className="w-4 h-4" />
            <span>Buscar sección…</span>
            <span className="ml-auto inline-flex items-center gap-1 text-[10px] text-white/50 border border-white/15 rounded px-1.5 py-[1px] font-[family-name:var(--font-cond)]">
              <Command className="w-3 h-3" />K
            </span>
          </button>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {NAV.map((item) => {
          const Icon = item.icon;
          if (item.children) {
            const open = openGroups[item.label];
            const anyActive = item.children.some((c) => pathname === c.to);
            return (
              <div key={item.label}>
                <button
                  type="button"
                  onClick={() =>
                    !collapsed || mobileOpen
                      ? setOpenGroups((g) => ({ ...g, [item.label]: !open }))
                      : navigate({ to: item.children![0].to })
                  }
                  className={cn(
                    "w-full flex items-center gap-3 rounded-lg h-10 px-3 text-[13.5px] font-[family-name:var(--font-cond)] font-semibold uppercase tracking-wide transition",
                    anyActive
                      ? "text-white bg-white/[0.06]"
                      : "text-white/70 hover:text-white hover:bg-white/[0.04]",
                    collapsed && !mobileOpen && "lg:justify-center lg:px-0",
                  )}
                >
                  <Icon className="w-[18px] h-[18px] shrink-0" />
                  {(!collapsed || mobileOpen) && (
                    <>
                      <span className="flex-1 text-left truncate">{item.label}</span>
                      <ChevronDown
                        className={cn("w-4 h-4 transition-transform", open && "rotate-180")}
                      />
                    </>
                  )}
                </button>
                {(!collapsed || mobileOpen) && open && (
                  <div className="pl-4 mt-1 mb-2 space-y-0.5 relative">
                    <span
                      aria-hidden
                      className="absolute left-[22px] top-1 bottom-1 w-px bg-white/10"
                    />
                    {item.children.map((c) => {
                      const active = pathname === c.to;
                      return (
                        <Link
                          key={c.label}
                          to={c.to}
                          hash={c.hash}
                          onClick={onMobileClose}
                          className={cn(
                            "flex items-center gap-3 pl-6 pr-3 h-8 rounded-md text-[12.5px] font-[family-name:var(--font-cond)] font-semibold uppercase tracking-wider transition",
                            active
                              ? "text-white bg-[color:var(--brand-red)] shadow-[0_6px_20px_-8px_rgba(200,16,46,0.7)]"
                              : "text-white/55 hover:text-white hover:bg-white/[0.05]",
                          )}
                        >
                          <span
                            aria-hidden
                            className={cn(
                              "w-1.5 h-1.5 rounded-full",
                              active ? "bg-white" : "bg-white/30",
                            )}
                          />
                          {c.label}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          }

          const active = pathname === item.to;
          return (
            <Link
              key={item.label}
              to={item.to!}
              onClick={onMobileClose}
              className={cn(
                "relative flex items-center gap-3 rounded-lg h-10 px-3 text-[13.5px] font-[family-name:var(--font-cond)] font-semibold uppercase tracking-wide transition",
                active
                  ? "text-white bg-[color:var(--brand-red)] shadow-[0_10px_24px_-10px_rgba(200,16,46,0.8)]"
                  : "text-white/70 hover:text-white hover:bg-white/[0.05]",
                collapsed && !mobileOpen && "lg:justify-center lg:px-0",
              )}
            >
              {active && (
                <span
                  aria-hidden
                  className="absolute -left-3 top-1/2 -translate-y-1/2 w-1.5 h-6 rounded-r bg-[color:var(--brand-amber)]"
                />
              )}
              <Icon className="w-[18px] h-[18px] shrink-0" />
              {(!collapsed || mobileOpen) && (
                <>
                  <span className="flex-1 truncate">{item.label}</span>
                  {item.badge && (
                    <span className="text-[10px] font-bold bg-[color:var(--brand-amber)] text-[color:var(--brand-navy)] px-1.5 py-0.5 rounded font-[family-name:var(--font-cond)]">
                      {item.badge}
                    </span>
                  )}
                </>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-white/5 p-3 space-y-2">
        <Link
          to="/auth"
          className={cn(
            "w-full flex items-center gap-2 rounded-lg h-10 px-3 bg-white/[0.03] hover:bg-[color:var(--brand-red)] text-white/80 hover:text-white text-[12px] uppercase font-[family-name:var(--font-cond)] font-bold tracking-wider transition border border-white/5",
            collapsed && !mobileOpen && "lg:justify-center lg:px-0",
          )}
        >
          <LogOut className="w-4 h-4" />
          {(!collapsed || mobileOpen) && <span>Cerrar sesión</span>}
        </Link>
      </div>
      </aside>
    </>
  );
}