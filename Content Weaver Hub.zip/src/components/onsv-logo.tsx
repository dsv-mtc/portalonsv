import { cn } from "@/lib/utils";

export function OnsvLogo({ className, tone = "light" }: { className?: string; tone?: "light" | "dark" }) {
  const bg = tone === "light" ? "#ffffff" : "#14213D";
  const ring = "#C8102E";
  const stroke = tone === "light" ? "#14213D" : "#ffffff";
  return (
    <div
      className={cn("grid place-items-center rounded-full shrink-0", className)}
      style={{ background: bg, boxShadow: `inset 0 0 0 3px ${ring}` }}
    >
      <svg viewBox="0 0 40 40" width="60%" height="60%" fill="none" stroke={stroke} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <circle cx="20" cy="20" r="12" />
        <path d="M14 22 L20 14 L26 22" />
        <path d="M14 22 h12" />
        <circle cx="16" cy="25" r="1.6" fill={stroke} stroke="none" />
        <circle cx="24" cy="25" r="1.6" fill={stroke} stroke="none" />
      </svg>
    </div>
  );
}

export function OnsvWordmark({ tone = "dark" }: { tone?: "dark" | "light" }) {
  const primary = tone === "dark" ? "#14213D" : "#ffffff";
  const accent = "#C8102E";
  return (
    <div className="flex flex-col leading-none font-[family-name:var(--font-display)] uppercase">
      <span className="text-[20px] font-extrabold tracking-tight" style={{ color: primary }}>
        Observatorio Nacional
      </span>
      <span className="text-[10px] font-bold tracking-[0.16em] mt-1 font-[family-name:var(--font-cond)]" style={{ color: accent }}>
        de Seguridad Vial
      </span>
    </div>
  );
}