import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function Kpi({
  color, icon, label, value, delta, trend = "up",
}: {
  color: string; icon: ReactNode; label: string; value: string; delta?: string; trend?: "up" | "down";
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-[color:var(--brand-line)] bg-white p-5 flex items-center gap-4" style={{ boxShadow: "var(--shadow-brand)" }}>
      <span aria-hidden className="absolute inset-y-0 left-0 w-[5px]" style={{ background: color }} />
      <div className="w-12 h-12 rounded-xl grid place-items-center shrink-0" style={{ background: `color-mix(in srgb, ${color} 12%, #fff)`, color }}>
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-[32px] leading-none font-extrabold text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)" }}>{value}</div>
        <div className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground mt-1 font-bold" style={{ fontFamily: "var(--font-cond)" }}>{label}</div>
        {delta && (
          <span className={cn("inline-block mt-2 text-[11px] font-bold px-2 py-0.5 rounded-full", trend === "up" ? "bg-[#fdecec] text-[color:var(--brand-red)]" : "bg-[#e8f5ec] text-[#1f7a44]")} style={{ fontFamily: "var(--font-cond)" }}>
            {trend === "up" ? "▲" : "▼"} {delta}
          </span>
        )}
      </div>
    </div>
  );
}

export function Panel({
  title, actions, children, className,
}: { title?: string; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-2xl border border-[color:var(--brand-line)] bg-white", className)} style={{ boxShadow: "var(--shadow-brand)" }}>
      {(title || actions) && (
        <header className="flex items-center justify-between gap-3 px-5 py-4 border-b border-[color:var(--brand-line)]">
          {title && <h3 className="text-[17px] uppercase text-[color:var(--brand-navy)] tracking-tight" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>{title}</h3>}
          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className="p-5">{children}</div>
    </section>
  );
}

export function BrandButton({
  children, variant = "red", className, ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "red" | "navy" | "outline" | "ghost" }) {
  const base = "inline-flex items-center gap-2 h-10 px-4 rounded-lg text-[12.5px] uppercase tracking-[0.05em] font-bold transition font-[family-name:var(--font-cond)] cursor-pointer";
  const variants: Record<string, string> = {
    red: "bg-[color:var(--brand-red)] text-white hover:bg-[color:var(--brand-red-dark)] shadow-[0_8px_20px_-10px_rgba(200,16,46,0.6)]",
    navy: "bg-[color:var(--brand-navy)] text-white hover:bg-[color:var(--brand-navy-2)]",
    outline: "border-2 border-[color:var(--brand-red)] text-[color:var(--brand-red)] hover:bg-[color:var(--brand-red)] hover:text-white bg-transparent",
    ghost: "text-[color:var(--brand-navy)] hover:bg-[color:var(--brand-mist)]",
  };
  return <button className={cn(base, variants[variant], className)} {...props}>{children}</button>;
}

export function BrandTable({ headers, rows }: { headers: string[]; rows: ReactNode[][] }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-[color:var(--brand-line)]">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-[color:var(--brand-navy)] text-white" style={{ fontFamily: "var(--font-cond)" }}>
            {headers.map((h) => (
              <th key={h} className="text-left uppercase tracking-[0.06em] text-[11.5px] font-bold px-4 py-3 whitespace-nowrap">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={cn("border-t border-[color:var(--brand-line)] hover:bg-[color:var(--brand-mist)] transition", i % 2 === 1 && "bg-[color:var(--brand-mist)]/40")}>
              {r.map((c, j) => (<td key={j} className="px-4 py-3 align-middle">{c}</td>))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Chip({ children, color = "cyan" }: { children: ReactNode; color?: "cyan" | "red" | "amber" | "green" | "navy" }) {
  const map: Record<string, string> = {
    cyan: "bg-[color-mix(in_srgb,var(--brand-cyan)_14%,#fff)] text-[color:var(--brand-cyan)]",
    red: "bg-[#fdecec] text-[color:var(--brand-red)]",
    amber: "bg-[color:var(--brand-amber)] text-[color:var(--brand-navy)]",
    green: "bg-[#e8f5ec] text-[#1f7a44]",
    navy: "bg-[color:var(--brand-navy)] text-white",
  };
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] uppercase font-bold tracking-[0.04em] font-[family-name:var(--font-cond)]", map[color])}>
      {children}
    </span>
  );
}