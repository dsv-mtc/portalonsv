import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Send, Languages } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/mision")({ component: MisionVision });

const FIELDS_ES = [
  { name: "def_es", label: "Definición ONSV", max: 10000, value: "El Observatorio Nacional de Seguridad Vial es el organismo técnico encargado…" },
  { name: "mis_es", label: "Misión", max: 2000, value: "Reducir de manera sostenida las víctimas de siniestros de tránsito en el Perú." },
  { name: "vis_es", label: "Visión", max: 2000, value: "Ser el referente latinoamericano de seguridad vial basado en datos al 2030." },
];
const FIELDS_EN = [
  { name: "def_en", label: "ONSV Definition", max: 10000, value: "The National Road Safety Observatory is the technical body…" },
  { name: "mis_en", label: "Mission", max: 10000, value: "Sustainably reduce road-crash victims in Peru." },
  { name: "vis_en", label: "Vision", max: 10000, value: "To be the Latin American benchmark for data-driven road safety by 2030." },
];

function MisionVision() {
  const [lang, setLang] = useState<"es" | "en">("es");
  const fields = lang === "es" ? FIELDS_ES : FIELDS_EN;
  return (
    <>
      <PageHeader title="Misión — Visión" eyebrow="Identidad institucional (ES / EN)"
        description="Define los textos institucionales bilingües del Portal ONSV." />

      <div className="mb-5 inline-flex rounded-lg border-2 border-[color:var(--brand-line)] p-1 bg-white">
        {(["es", "en"] as const).map((l) => (
          <button key={l} onClick={() => setLang(l)}
            className={"px-4 h-9 rounded-md text-[12px] uppercase font-bold tracking-wider transition font-[family-name:var(--font-cond)] inline-flex items-center gap-2 " +
              (lang === l ? "bg-[color:var(--brand-navy)] text-white" : "text-[color:var(--brand-navy)] hover:bg-[color:var(--brand-mist)]")}>
            <Languages className="w-3.5 h-3.5" /> {l === "es" ? "Español" : "English"}
          </button>
        ))}
      </div>

      <form onSubmit={(e) => e.preventDefault()}>
        <Panel title={lang === "es" ? "Textos institucionales" : "Institutional texts"}>
          <div className="space-y-5">
            {fields.map((f) => (
              <label key={f.name} className="block">
                <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>
                  {f.label} <span className="text-[color:var(--brand-red)]">*</span>
                </span>
                <textarea required maxLength={f.max} defaultValue={f.value}
                  className="mt-1 w-full min-h-[140px] rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none p-3 text-[14.5px] leading-relaxed resize-y" />
                <span className="text-[10.5px] text-muted-foreground mt-1 inline-block">Máx. {f.max.toLocaleString()} caracteres</span>
              </label>
            ))}
          </div>
          <div className="mt-6 flex justify-end">
            <BrandButton type="submit"><Send className="w-4 h-4" /> Enviar Información</BrandButton>
          </div>
        </Panel>
      </form>
    </>
  );
}
