import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Search, RotateCcw, Pencil, MapPin, Image as ImageIcon, X, Save, ChevronLeft, ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton, BrandTable } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/regiones")({ component: Regiones });

const REGIONES = [
  { name: "Amazonas", slug: "amazonas", coord: "—", cel: "—", email: "amazonas@onsv.gob.pe", img: "amazonas.jpg" },
  { name: "Áncash", slug: "ancash", coord: "—", cel: "—", email: "ancash@onsv.gob.pe", img: "ancash.jpg" },
  { name: "Apurímac", slug: "apurimac", coord: "—", cel: "—", email: "apurimac@onsv.gob.pe", img: "apurimac.jpg" },
  { name: "Arequipa", slug: "arequipa", coord: "Marco Torres", cel: "959 220 341", email: "arequipa@onsv.gob.pe", img: "arequipa.jpg" },
  { name: "Ayacucho", slug: "ayacucho", coord: "—", cel: "—", email: "ayacucho@onsv.gob.pe", img: "ayacucho.jpg" },
  { name: "Cajamarca", slug: "cajamarca", coord: "—", cel: "—", email: "cajamarca@onsv.gob.pe", img: "cajamarca.jpg" },
  { name: "Callao", slug: "callao", coord: "—", cel: "—", email: "callao@onsv.gob.pe", img: "callao.jpg" },
  { name: "Cusco", slug: "cusco", coord: "Elena Ríos", cel: "984 555 111", email: "cusco@onsv.gob.pe", img: "cusco.jpg" },
  { name: "Huancavelica", slug: "huancavelica", coord: "—", cel: "—", email: "huancavelica@onsv.gob.pe", img: "huancavelica.jpg" },
  { name: "Huánuco", slug: "huanuco", coord: "—", cel: "—", email: "huanuco@onsv.gob.pe", img: "huanuco.jpg" },
  { name: "Ica", slug: "ica", coord: "—", cel: "—", email: "ica@onsv.gob.pe", img: "ica.jpg" },
  { name: "Junín", slug: "junin", coord: "—", cel: "—", email: "junin@onsv.gob.pe", img: "junin.jpg" },
  { name: "La Libertad", slug: "la-libertad", coord: "Ana Mendoza", cel: "944 700 123", email: "lalibertad@onsv.gob.pe", img: "lalibertad.jpg" },
  { name: "Lambayeque", slug: "lambayeque", coord: "—", cel: "—", email: "lambayeque@onsv.gob.pe", img: "lambayeque.jpg" },
  { name: "Lima", slug: "lima", coord: "Julio Vargas", cel: "999 111 222", email: "lima@onsv.gob.pe", img: "lima.jpg" },
  { name: "Loreto", slug: "loreto", coord: "José Panduro", cel: "965 400 090", email: "loreto@onsv.gob.pe", img: "loreto.jpg" },
  { name: "Madre de Dios", slug: "madre-de-dios", coord: "—", cel: "—", email: "madrededios@onsv.gob.pe", img: "madrededios.jpg" },
  { name: "Moquegua", slug: "moquegua", coord: "—", cel: "—", email: "moquegua@onsv.gob.pe", img: "moquegua.jpg" },
  { name: "Pasco", slug: "pasco", coord: "—", cel: "—", email: "pasco@onsv.gob.pe", img: "pasco.jpg" },
  { name: "Piura", slug: "piura", coord: "—", cel: "—", email: "piura@onsv.gob.pe", img: "piura.jpg" },
  { name: "Puno", slug: "puno", coord: "—", cel: "—", email: "puno@onsv.gob.pe", img: "puno.jpg" },
  { name: "San Martín", slug: "san-martin", coord: "—", cel: "—", email: "sanmartin@onsv.gob.pe", img: "sanmartin.jpg" },
  { name: "Tacna", slug: "tacna", coord: "—", cel: "—", email: "tacna@onsv.gob.pe", img: "tacna.jpg" },
  { name: "Tumbes", slug: "tumbes", coord: "—", cel: "—", email: "tumbes@onsv.gob.pe", img: "tumbes.jpg" },
  { name: "Ucayali", slug: "ucayali", coord: "—", cel: "—", email: "ucayali@onsv.gob.pe", img: "ucayali.jpg" },
];

type Region = (typeof REGIONES)[number];

function Regiones() {
  const [editing, setEditing] = useState<Region | null>(null);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize] = useState(6);

  const filtered = query === "" || query === "Todas"
    ? REGIONES
    : REGIONES.filter((r) => r.name === query);
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const start = (currentPage - 1) * pageSize;
  const pageRows = filtered.slice(start, start + pageSize);

  return (
    <>
      <PageHeader title="Regiones" eyebrow="Consejos Regionales de Seguridad Vial"
        description="Consulta y edita la información de cada región. Solo se permite editar (no crear ni eliminar)." />

      <Panel title="Filtro" className="mb-6">
        <div className="flex flex-wrap items-end gap-3">
          <label className="block flex-1 min-w-[220px]">
            <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Región</span>
            <select
              value={query}
              onChange={(e) => { setQuery(e.target.value); setPage(1); }}
              className="mt-1 w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3 bg-white"
            >
              <option>Todas</option>
              {REGIONES.map((r) => <option key={r.slug}>{r.name}</option>)}
            </select>
          </label>
          <BrandButton><Search className="w-4 h-4" /> Consultar</BrandButton>
          <BrandButton variant="outline" onClick={() => { setQuery(""); setPage(1); }}><RotateCcw className="w-4 h-4" /> Limpiar</BrandButton>
        </div>
      </Panel>

      <Panel title={`${filtered.length} regiones`}>
        <BrandTable headers={["Región", "Slug", "Nombre encargado", "Celular encargado", "Correo encargado", "Imagen", "Acciones"]}
          rows={pageRows.map((r) => [
            <div key="n" className="flex items-center gap-2"><MapPin className="w-4 h-4 text-[color:var(--brand-red)]" /><b className="text-[color:var(--brand-navy)]">{r.name}</b></div>,
            <code key="s" className="text-[12px] text-muted-foreground">{r.slug}</code>,
            r.coord,
            r.cel,
            r.email,
            <span key="i" className="inline-flex items-center gap-1.5 text-[12.5px] text-[color:var(--brand-cyan)]"><ImageIcon className="w-3.5 h-3.5" />{r.img}</span>,
            <button key="a" onClick={() => setEditing(r)} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>,
          ])} />
        <div className="mt-4 flex flex-wrap items-center justify-end gap-3">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="w-9 h-9 grid place-items-center rounded-lg border-2 border-[color:var(--brand-line)] text-[color:var(--brand-navy)] hover:bg-[color:var(--brand-mist)] disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={
                  "w-9 h-9 rounded-lg text-[13px] font-bold font-[family-name:var(--font-cond)] transition " +
                  (p === currentPage
                    ? "bg-[color:var(--brand-red)] text-white shadow-[0_6px_16px_-8px_rgba(200,16,46,0.7)]"
                    : "border-2 border-[color:var(--brand-line)] text-[color:var(--brand-navy)] hover:bg-[color:var(--brand-mist)]")
                }
              >
                {p}
              </button>
            ))}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="w-9 h-9 grid place-items-center rounded-lg border-2 border-[color:var(--brand-line)] text-[color:var(--brand-navy)] hover:bg-[color:var(--brand-mist)] disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </Panel>

      {editing && <EditModal region={editing} onClose={() => setEditing(null)} />}
    </>
  );
}

function EditModal({ region, onClose }: { region: Region; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-2xl rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5" style={{ background: "linear-gradient(90deg,#C8102E,#F4B41A)" }} />
        <header className="flex items-center justify-between px-5 py-4 border-b border-[color:var(--brand-line)]">
          <div>
            <span className="onsv-eyebrow">Editar región</span>
            <h3 className="mt-1 text-[22px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>{region.name}</h3>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)]"><X className="w-4 h-4" /></button>
        </header>
        <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {[
            { label: "Nombre encargado", value: region.coord, type: "text" },
            { label: "Celular encargado", value: region.cel, type: "text" },
            { label: "Correo encargado", value: region.email, type: "email" },
            { label: "Enlace página", value: `https://onsv.gob.pe/regiones/${region.slug}`, type: "url" },
          ].map((f) => (
            <label key={f.label} className="block">
              <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>{f.label}</span>
              <input type={f.type} defaultValue={f.value} maxLength={2000} className="mt-1 w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3" />
            </label>
          ))}
          <label className="block">
            <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Imagen</span>
            <input type="file" accept="image/*" className="mt-1 w-full text-[13px] file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-[color:var(--brand-navy)] file:text-white file:cursor-pointer" />
          </label>
          <footer className="flex justify-end gap-2 pt-2">
            <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
            <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar cambios</BrandButton>
          </footer>
        </form>
      </div>
    </div>
  );
}
