import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Pencil, Trash2, Shield, User as UserIcon, X, Save } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton, Chip, BrandTable } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/usuarios")({ component: Usuarios });

const USERS = [
  { email: "ana.ordonez@onsv.gob.pe", role: "Superadministrador", init: "AO" },
  { email: "luis.palomino@onsv.gob.pe", role: "Editor", init: "LP" },
  { email: "marta.rios@onsv.gob.pe", role: "Editor regional", init: "MR" },
  { email: "carlos.vega@onsv.gob.pe", role: "Visualizador", init: "CV" },
];
type Usr = (typeof USERS)[number];

const ROLES = [
  { name: "Superadministrador", perms: ["content_management:acceder", "content_management:crear", "content_management:actualizar", "content_management:eliminar", "consejo_regional:acceder", "plan_regional:acceder", "plan_regional:crear", "plan_regional:actualizar", "plan_regional:eliminar"] },
  { name: "Editor", perms: ["content_management:acceder", "content_management:crear", "content_management:actualizar", "plan_regional:acceder", "plan_regional:actualizar"] },
  { name: "Editor regional", perms: ["content_management:acceder", "content_management:actualizar", "consejo_regional:acceder", "plan_regional:acceder"] },
  { name: "Visualizador", perms: ["content_management:acceder", "consejo_regional:acceder", "plan_regional:acceder"] },
];
type Rol = (typeof ROLES)[number];

const PERMISSION_GROUPS: { key: string; label: string; actions: { id: string; label: string }[] }[] = [
  {
    key: "content_management",
    label: "Manejo de contenidos",
    actions: [
      { id: "acceder", label: "Acceder" },
      { id: "crear", label: "Crear" },
      { id: "actualizar", label: "Actualizar" },
      { id: "eliminar", label: "Eliminar" },
    ],
  },
  { key: "consejo_regional", label: "Consejo Regional", actions: [{ id: "acceder", label: "Acceder (sólo lectura)" }] },
  {
    key: "plan_regional",
    label: "Plan Regional",
    actions: [
      { id: "acceder", label: "Acceder" },
      { id: "crear", label: "Crear" },
      { id: "actualizar", label: "Actualizar" },
      { id: "eliminar", label: "Eliminar" },
    ],
  },
];

function TabLink({ to, active, children, icon }: { to: string; active: boolean; children: React.ReactNode; icon: React.ReactNode }) {
  return <a href={to} className={"px-4 h-11 -mb-px inline-flex items-center gap-2 text-[13px] uppercase font-bold tracking-wider transition font-[family-name:var(--font-cond)] " + (active ? "text-[color:var(--brand-red)] border-b-2 border-[color:var(--brand-red)]" : "text-muted-foreground hover:text-[color:var(--brand-navy)] border-b-2 border-transparent")}>{icon}{children}</a>;
}

const inputCls = "w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3";

function Usuarios() {
  const hash = useRouterState({ select: (s) => s.location.hash });
  const tab = hash === "roles" ? "roles" : "usuarios";
  const [uModal, setUModal] = useState<null | { mode: "add" | "edit"; row?: Usr }>(null);
  const [rModal, setRModal] = useState<null | { mode: "add" | "edit"; row?: Rol }>(null);
  const [del, setDel] = useState<null | string>(null);

  return (
    <>
      <PageHeader title="Gestión de usuarios" eyebrow="Accesos y permisos"
        description="Administra los usuarios que acceden al panel y los roles que definen sus permisos."
        actions={<BrandButton onClick={() => tab === "usuarios" ? setUModal({ mode: "add" }) : setRModal({ mode: "add" })}>
          <Plus className="w-4 h-4" /> {tab === "usuarios" ? "Agregar" : "Crear rol"}
        </BrandButton>} />

      <div className="flex gap-2 mb-6 border-b border-[color:var(--brand-line)]">
        <TabLink to="#usuarios" active={tab === "usuarios"} icon={<UserIcon className="w-4 h-4" />}>Usuarios</TabLink>
        <TabLink to="#roles" active={tab === "roles"} icon={<Shield className="w-4 h-4" />}>Roles</TabLink>
      </div>

      {tab === "usuarios" ? (
        <Panel title={`${USERS.length} usuarios registrados`}>
          <BrandTable headers={["Usuario", "Rol", "Acciones"]}
            rows={USERS.map((u) => [
              <div key="u" className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full grid place-items-center text-white text-[12px] font-extrabold shrink-0" style={{ background: "linear-gradient(135deg,#14213D,#1F3864)", fontFamily: "var(--font-display)" }}>{u.init}</div>
                <b className="text-[color:var(--brand-navy)]">{u.email}</b>
              </div>,
              <Chip key="r" color={u.role === "Superadministrador" ? "red" : u.role === "Editor" ? "navy" : u.role === "Editor regional" ? "cyan" : "amber"}>{u.role}</Chip>,
              <div key="a" className="flex gap-1">
                <button onClick={() => setUModal({ mode: "edit", row: u })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel(u.email)} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
              </div>,
            ])} />
        </Panel>
      ) : (
        <Panel title={`${ROLES.length} roles`}>
          <BrandTable headers={["Rol", "Permisos", "Acciones"]}
            rows={ROLES.map((r) => [
              <div key="n" className="flex items-center gap-2"><Shield className="w-4 h-4 text-[color:var(--brand-red)]" /><b className="text-[color:var(--brand-navy)]">{r.name}</b></div>,
              <div key="p" className="flex flex-wrap gap-1 max-w-[520px]">
                {r.perms.map((p) => <Chip key={p} color="cyan">{p}</Chip>)}
              </div>,
              <div key="a" className="flex gap-1">
                <button onClick={() => setRModal({ mode: "edit", row: r })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel(r.name)} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
              </div>,
            ])} />
        </Panel>
      )}

      {uModal && <UserModal mode={uModal.mode} row={uModal.row} onClose={() => setUModal(null)} />}
      {rModal && <RoleModal mode={rModal.mode} row={rModal.row} onClose={() => setRModal(null)} />}
      {del && <DeleteModal name={del} onClose={() => setDel(null)} />}
    </>
  );
}

function ModalShell({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className={"relative w-full rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden " + (wide ? "max-w-2xl" : "max-w-md")} onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5" style={{ background: "linear-gradient(90deg,#C8102E,#F4B41A)" }} />
        <header className="flex items-center justify-between px-5 py-4 border-b border-[color:var(--brand-line)]">
          <h3 className="text-[18px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>{title}</h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)]"><X className="w-4 h-4" /></button>
        </header>
        {children}
      </div>
    </div>
  );
}

function UserModal({ mode, row, onClose }: { mode: "add" | "edit"; row?: Usr; onClose: () => void }) {
  return (
    <ModalShell title={mode === "add" ? "Nuevo usuario" : "Editar usuario"} onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 space-y-4">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Usuario (correo) <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required type="email" defaultValue={row?.email} className={"mt-1 " + inputCls} />
        </label>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>
            {mode === "add" ? <>Contraseña <span className="text-[color:var(--brand-red)]">*</span></> : "Nueva contraseña (opcional)"}
          </span>
          <input required={mode === "add"} type="password" className={"mt-1 " + inputCls} placeholder={mode === "edit" ? "Dejar en blanco para no cambiar" : ""} />
        </label>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Rol</span>
          <select defaultValue={row?.role} className={"mt-1 bg-white " + inputCls}>
            <option value="">Seleccione…</option>
            {ROLES.map((r) => <option key={r.name}>{r.name}</option>)}
          </select>
        </label>
        <footer className="flex justify-end gap-2 pt-2">
          <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
          <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
        </footer>
      </form>
    </ModalShell>
  );
}

function RoleModal({ mode, row, onClose }: { mode: "add" | "edit"; row?: Rol; onClose: () => void }) {
  const allIds = PERMISSION_GROUPS.flatMap((g) => g.actions.map((a) => `${g.key}:${a.id}`));
  const initial = mode === "add" ? new Set(allIds) : new Set(row?.perms ?? []);
  const [checked, setChecked] = useState<Set<string>>(initial);
  const allOn = allIds.every((id) => checked.has(id));
  const toggle = (id: string) => setChecked((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleAll = () => setChecked(allOn ? new Set() : new Set(allIds));

  return (
    <ModalShell wide title={mode === "add" ? "Crear rol" : "Editar rol"} onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 space-y-5 max-h-[75vh] overflow-y-auto">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Rol <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required maxLength={2000} defaultValue={row?.name} className={"mt-1 " + inputCls} />
        </label>

        <label className="flex items-center gap-3 rounded-lg border-2 border-dashed border-[color:var(--brand-navy)] px-3 h-11 bg-[color:var(--brand-mist)]">
          <input type="checkbox" checked={allOn} onChange={toggleAll} className="w-4 h-4 accent-[color:var(--brand-red)]" />
          <span className="text-[12.5px] uppercase font-bold tracking-wider text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-cond)" }}>Seleccionar todo</span>
        </label>

        <div className="space-y-4">
          {PERMISSION_GROUPS.map((g) => (
            <div key={g.key} className="rounded-xl border border-[color:var(--brand-line)] p-4">
              <div className="text-[13px] uppercase text-[color:var(--brand-navy)] font-bold tracking-wider mb-3" style={{ fontFamily: "var(--font-cond)" }}>
                {g.label} <span className="text-muted-foreground text-[11px] font-normal ml-1">— {g.key}</span>
              </div>
              <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-2">
                {g.actions.map((a) => {
                  const id = `${g.key}:${a.id}`;
                  const on = checked.has(id);
                  return (
                    <label key={id} className={"flex items-center gap-2 rounded-lg border-2 px-3 h-10 cursor-pointer transition " + (on ? "border-[color:var(--brand-red)] bg-[#fdecec]" : "border-[color:var(--brand-line)] hover:border-[color:var(--brand-navy)]")}>
                      <input type="checkbox" checked={on} onChange={() => toggle(id)} className="w-4 h-4 accent-[color:var(--brand-red)]" />
                      <span className="text-[13px] font-semibold text-[color:var(--brand-navy)]">{a.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <footer className="flex justify-end gap-2 pt-2">
          <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
          <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
        </footer>
      </form>
    </ModalShell>
  );
}

function DeleteModal({ name, onClose }: { name: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-md rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5 bg-[color:var(--brand-red)]" />
        <div className="p-6 text-center">
          <div className="w-14 h-14 rounded-full grid place-items-center mx-auto mb-3 bg-[#fdecec] text-[color:var(--brand-red)]"><Trash2 className="w-6 h-6" /></div>
          <h3 className="text-[20px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>Confirmar eliminación</h3>
          <p className="mt-2 text-[13.5px] text-muted-foreground">Se eliminará esta información, ¿Está seguro?</p>
          <p className="mt-2 text-[13px] font-semibold text-[color:var(--brand-navy)]">{name}</p>
          <div className="mt-5 flex justify-center gap-2">
            <BrandButton variant="outline" onClick={onClose}>Cancelar</BrandButton>
            <BrandButton onClick={onClose}>Eliminar</BrandButton>
          </div>
        </div>
      </div>
    </div>
  );
}
