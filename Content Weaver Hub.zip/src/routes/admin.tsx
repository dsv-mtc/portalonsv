import { createFileRoute, Outlet, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Activity, ChevronRight, Home, Menu } from "lucide-react";
import { AdminSidebar } from "@/components/admin-sidebar";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Panel ONSV — Administración" },
      { name: "description", content: "Panel administrativo del Portal ONSV." },
    ],
  }),
  component: AdminLayout,
});

function AdminLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-[color:var(--brand-mist)]">
      <AdminSidebar
        collapsed={collapsed}
        onToggle={() => setCollapsed((c) => !c)}
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <div className="onsv-ribbon text-center py-1.5 px-4 sm:px-6 text-[11px] sm:text-[12px]" style={{ letterSpacing: "0.14em" }}>
          Portal ONSV · <b className="text-[color:var(--brand-amber)]">Panel Administrativo</b> · MTC
        </div>

        <header className="sticky top-0 z-30 bg-white/85 backdrop-blur border-b border-[color:var(--brand-line)]">
          <div className="flex items-center gap-2 sm:gap-4 h-16 px-3 sm:px-6">
            <button
              type="button"
              onClick={() => {
                if (window.matchMedia("(min-width: 1024px)").matches) {
                  setCollapsed((c) => !c);
                } else {
                  setMobileOpen(true);
                }
              }}
              aria-label="Alternar menú"
              title="Alternar menú"
              className="w-10 h-10 rounded-lg border border-[color:var(--brand-line)] bg-white grid place-items-center text-[color:var(--brand-navy)] hover:border-[color:var(--brand-red)] hover:text-[color:var(--brand-red)] transition shrink-0"
            >
              <Menu className="w-4 h-4" />
            </button>
            <nav aria-label="Migas" className="flex items-center gap-2 text-[11px] sm:text-[12px] uppercase tracking-[0.1em] min-w-0" style={{ fontFamily: "var(--font-cond)" }}>
              <Link to="/admin" className="flex items-center gap-1.5 text-muted-foreground hover:text-[color:var(--brand-red)] font-bold">
                <Home className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Panel</span>
              </Link>
              <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/50 shrink-0" />
              <span className="text-[color:var(--brand-navy)] font-extrabold truncate">Administración</span>
            </nav>

            <div className="ml-auto flex items-center gap-2 sm:gap-3 shrink-0">
              <div
                title="Estado del portal"
                className="flex items-center gap-2 h-10 px-3 rounded-lg border border-[color:var(--brand-line)] bg-white text-[color:var(--brand-navy)]"
              >
                <Activity className="w-4 h-4 text-[color:var(--brand-cyan)]" />
                <span
                  className="hidden sm:inline text-[11px] font-bold uppercase tracking-[0.14em] text-[#1f7a44]"
                  style={{ fontFamily: "var(--font-cond)" }}
                >
                  Online
                </span>
                <span className="relative flex w-2 h-2">
                  <span className="absolute inline-flex w-full h-full rounded-full bg-[#22c55e] opacity-70 animate-ping" />
                  <span className="relative inline-flex w-2 h-2 rounded-full bg-[#1f7a44]" />
                </span>
              </div>
              <div className="hidden md:flex items-center gap-3 pl-3 border-l border-[color:var(--brand-line)]">
                <div className="text-right leading-none">
                  <div className="text-[13px] font-bold text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-cond)" }}>Admin ONSV</div>
                  <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mt-1" style={{ fontFamily: "var(--font-cond)" }}>Superadministrador</div>
                </div>
                <div className="w-10 h-10 rounded-full grid place-items-center text-white font-extrabold text-[14px] shadow-[0_6px_18px_-6px_rgba(200,16,46,0.7)]" style={{ background: "linear-gradient(135deg,#C8102E,#9E0C24)", fontFamily: "var(--font-display)" }}>
                  AO
                </div>
              </div>
              <div className="md:hidden w-9 h-9 rounded-full grid place-items-center text-white font-extrabold text-[12px] shadow-[0_6px_18px_-6px_rgba(200,16,46,0.7)]" style={{ background: "linear-gradient(135deg,#C8102E,#9E0C24)", fontFamily: "var(--font-display)" }}>
                AO
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-10">
          <div className="max-w-[1360px] mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}