import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Pencil, Trash2, Search, RotateCcw, X, Save, Calendar } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton, Chip, BrandTable } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/comunicaciones")({ component: Comunicaciones });

const TYPES = ["Campaña", "Evento", "Entrevista", "Conferencia"];
const EVENTS = [
  { tipo: "Campaña", titulo: "Semana de la Seguridad Vial 2025", org: "ONSV", lugar: "Nacional", dir: "Perú", desc: "Semana nacional de actividades.", ini: "2025-05-12", fin: "2025-05-18", activo: true },
  { tipo: "Evento", titulo: "Foro internacional: Cero muertes viales", org: "ONSV / MTC", lugar: "Lima Convention Center", dir: "Av. de la Peruanidad s/n", desc: "Foro internacional.", ini: "2025-06-06", fin: "2025-06-07", activo: false },
  { tipo: "Entrevista", titulo: "Entrevista RPP: velocidad urbana", org: "RPP", lugar: "Estudio RPP", dir: "Av. Paseo de la República", desc: "Entrevista radial.", ini: "2025-05-27", fin: "2025-05-27", activo: true },
];
type Ev = (typeof EVENTS)[number];

function Comunicaciones() {
  const [modal, setModal] = useState<null | { mode: "add" | "edit"; ev?: Ev }>(null);
  const [del, setDel] = useState<Ev | null>(null);
  return (
    <>
      <PageHeader title="Comunicaciones" eyebrow="Eventos, campañas y entrevistas"
        description="Programa las publicaciones del calendario del portal público."
        actions={<BrandButton onClick={() => setModal({ mode: "add" })}><Plus className="w-4 h-4" /> Agregar</BrandButton>} />

      <Panel title="Filtros" className="mb-6">
        <div className="grid md:grid-cols-4 gap-3 items-end">
          <FilterInput label="Evento" placeholder="Buscar por título…" />
          <FilterSelect label="Tipo evento" options={["Todos", ...TYPES]} />
          <FilterInput label="Fecha inicio" type="date" />
          <FilterInput label="Fecha fin" type="date" />
          <div className="md:col-span-4 flex gap-2">
            <BrandButton><Search className="w-4 h-4" /> Consultar</BrandButton>
            <BrandButton variant="outline"><RotateCcw className="w-4 h-4" /> Limpiar</BrandButton>
          </div>
        </div>
      </Panel>

      <Panel title="Eventos programados">
        <BrandTable headers={["Tipo", "Evento", "Organizador", "Lugar", "Dirección", "Descripción", "Fecha inicio", "Fecha fin", "Estado", "Acciones"]}
          rows={EVENTS.map((e) => [
            <Chip key="t" color="cyan">{e.tipo}</Chip>,
            <b key="n" className="text-[color:var(--brand-navy)]">{e.titulo}</b>,
            e.org,
            e.lugar,
            <span key="d" className="text-[12.5px]">{e.dir}</span>,
            <span key="ds" className="text-[12.5px] text-muted-foreground line-clamp-2 max-w-[200px] inline-block">{e.desc}</span>,
            e.ini,
            e.fin,
            <Chip key="s" color={e.activo ? "green" : "red"}>{e.activo ? "Activo" : "Inactivo"}</Chip>,
            <div key="a" className="flex gap-1">
              <button onClick={() => setModal({ mode: "edit", ev: e })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
              <button onClick={() => setDel(e)} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
            </div>,
          ])} />
        <div className="flex items-center justify-between mt-4 text-[12.5px] text-muted-foreground">
          <span>Mostrando 1–{EVENTS.length} de {EVENTS.length}</span>
          <div className="flex gap-1">
            <button className="px-3 h-8 rounded-lg border border-[color:var(--brand-line)]">‹</button>
            <button className="px-3 h-8 rounded-lg bg-[color:var(--brand-navy)] text-white">1</button>
            <button className="px-3 h-8 rounded-lg border border-[color:var(--brand-line)]">›</button>
          </div>
        </div>
      </Panel>

      {modal && <EventModal mode={modal.mode} ev={modal.ev} onClose={() => setModal(null)} />}
      {del && <DeleteModal ev={del} onClose={() => setDel(null)} />}
    </>
  );
}

function FilterInput({ label, ...rest }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>{label}</span>
      <input {...rest} className="mt-1 w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3" />
    </label>
  );
}
function FilterSelect({ label, options }: { label: string; options: string[] }) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>{label}</span>
      <select className="mt-1 w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3 bg-white">
        {options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </label>
  );
}

function Field({ label, required, children, full }: { label: string; required?: boolean; children: React.ReactNode; full?: boolean }) {
  return (
    <label className={"block " + (full ? "sm:col-span-2" : "")}>
      <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>
        {label} {required && <span className="text-[color:var(--brand-red)]">*</span>}
      </span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
const inputCls = "w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3";
const areaCls = "w-full min-h-[90px] rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3 py-2";

function EventModal({ mode, ev, onClose }: { mode: "add" | "edit"; ev?: Ev; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-3xl rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5" style={{ background: "linear-gradient(90deg,#C8102E,#F4B41A)" }} />
        <header className="flex items-center justify-between px-5 py-4 border-b border-[color:var(--brand-line)]">
          <div>
            <span className="onsv-eyebrow">{mode === "add" ? "Nuevo evento" : "Editar evento"}</span>
            <h3 className="mt-1 text-[20px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}><Calendar className="inline w-5 h-5 mr-2" />{ev?.titulo ?? "Agregar evento"}</h3>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)]"><X className="w-4 h-4" /></button>
        </header>
        <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 max-h-[75vh] overflow-y-auto">
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Tipo de evento" required>
              <select required defaultValue={ev?.tipo} className={inputCls + " bg-white"}>
                <option value="">Seleccione…</option>
                {TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="Título" required><input required defaultValue={ev?.titulo} className={inputCls} /></Field>
            <Field label="Organizador" required><input required defaultValue={ev?.org} className={inputCls} /></Field>
            <Field label="Lugar"><input defaultValue={ev?.lugar} className={inputCls} /></Field>
            <Field label="Dirección" full><input defaultValue={ev?.dir} className={inputCls} /></Field>
            <Field label="Descripción corta" full><textarea maxLength={2000} defaultValue={ev?.desc} className={areaCls} /></Field>
            <Field label="Descripción (editor)" full>
              <div className="rounded-lg border-2 border-[color:var(--brand-line)] overflow-hidden">
                <div className="flex gap-1 px-2 py-1.5 bg-[color:var(--brand-mist)] border-b border-[color:var(--brand-line)] text-[11px] font-bold text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-cond)" }}>
                  <span className="px-2 py-0.5 rounded bg-white">B</span>
                  <span className="px-2 py-0.5 rounded bg-white italic">I</span>
                  <span className="px-2 py-0.5 rounded bg-white underline">U</span>
                  <span className="ml-2 text-muted-foreground uppercase">CKEditor 5</span>
                </div>
                <textarea className="w-full min-h-[140px] px-3 py-2 outline-none" placeholder="Descripción detallada…" />
              </div>
            </Field>
            <Field label="Día de inicio" required><input required type="date" defaultValue={ev?.ini} className={inputCls} /></Field>
            <Field label="Hora de inicio" required><input required type="time" defaultValue="09:00" className={inputCls} /></Field>
            <Field label="Día de finalización"><input type="date" defaultValue={ev?.fin} className={inputCls} /></Field>
            <Field label="Hora de finalización"><input type="time" defaultValue="18:00" className={inputCls} /></Field>
            <Field label="Precio"><input pattern="[0-9.]*" placeholder="Dejar en blanco para gratis" className={inputCls} /></Field>
            <Field label="Imagen"><input type="file" accept="image/*" className="w-full text-[13px] file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-[color:var(--brand-navy)] file:text-white file:cursor-pointer" /></Field>
            <Field label="Enlace reunión"><input type="url" className={inputCls} /></Field>
            <Field label="Enlace Facebook"><input type="url" className={inputCls} /></Field>
            <Field label="Enlace YouTube"><input type="url" className={inputCls} /></Field>
            <Field label="Enlace Twitter"><input type="url" className={inputCls} /></Field>
            <label className="sm:col-span-2 flex items-center gap-3 rounded-lg border-2 border-[color:var(--brand-line)] px-3 h-11">
              <input type="checkbox" defaultChecked={mode === "add" ? true : ev?.activo} className="w-4 h-4 accent-[color:var(--brand-red)]" />
              <span className="text-[13px] font-semibold text-[color:var(--brand-navy)]">¿Está activo?</span>
            </label>
          </div>
          <footer className="flex justify-end gap-2 pt-5">
            <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
            <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
          </footer>
        </form>
      </div>
    </div>
  );
}

function DeleteModal({ ev, onClose }: { ev: Ev; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-md rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5 bg-[color:var(--brand-red)]" />
        <div className="p-6 text-center">
          <div className="w-14 h-14 rounded-full grid place-items-center mx-auto mb-3 bg-[#fdecec] text-[color:var(--brand-red)]"><Trash2 className="w-6 h-6" /></div>
          <h3 className="text-[20px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>Eliminar evento</h3>
          <p className="mt-2 text-[13.5px] text-muted-foreground">Se eliminará esta información, ¿Está seguro?</p>
          <p className="mt-2 text-[13px] font-semibold text-[color:var(--brand-navy)]">{ev.titulo}</p>
          <div className="mt-5 flex justify-center gap-2">
            <BrandButton variant="outline" onClick={onClose}>Cancelar</BrandButton>
            <BrandButton onClick={onClose}>Eliminar</BrandButton>
          </div>
        </div>
      </div>
    </div>
  );
}
