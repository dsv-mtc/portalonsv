import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Pencil, Trash2, Menu as MenuIcon, ListTree, X, Save, ExternalLink, Image as ImageIcon } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton, Chip, BrandTable } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/analitica")({ component: Analitica });

const MENUS = [
  { id: 1, name: "Accidentes de tránsito", img: "accidentes.jpg", activo: true },
  { id: 2, name: "Fiscalización", img: "fiscalizacion.jpg", activo: true },
  { id: 3, name: "Educación vial", img: "educacion.jpg", activo: true },
  { id: 4, name: "Infraestructura", img: "infra.jpg", activo: false },
];
const SUBMENUS = [
  { menu: "Accidentes de tránsito", sub: "Por región", ruta: "bi.mtc.gob.pe/onsv/acc-regiones", video: "youtube.com/watch?v=1", pdf: "docs.gob.pe/acc.pdf", img: "acc-reg.jpg", activo: true },
  { menu: "Accidentes de tránsito", sub: "Por grupo etario", ruta: "bi.mtc.gob.pe/onsv/acc-edades", video: "", pdf: "", img: "acc-eda.jpg", activo: true },
  { menu: "Fiscalización", sub: "Operativos por mes", ruta: "bi.mtc.gob.pe/onsv/fisca-mes", video: "", pdf: "", img: "", activo: false },
];

function TabLink({ to, active, children, icon }: { to: string; active: boolean; children: React.ReactNode; icon: React.ReactNode }) {
  return <a href={to} className={"px-4 h-11 -mb-px inline-flex items-center gap-2 text-[13px] uppercase font-bold tracking-wider transition font-[family-name:var(--font-cond)] " + (active ? "text-[color:var(--brand-red)] border-b-2 border-[color:var(--brand-red)]" : "text-muted-foreground hover:text-[color:var(--brand-navy)] border-b-2 border-transparent")}>{icon}{children}</a>;
}

function Analitica() {
  const hash = useRouterState({ select: (s) => s.location.hash });
  const tab = hash === "submenu" ? "submenu" : "menu";
  const [menuModal, setMenuModal] = useState<null | { mode: "add" | "edit"; row?: typeof MENUS[number] }>(null);
  const [subModal, setSubModal] = useState<null | { mode: "add" | "edit"; row?: typeof SUBMENUS[number] }>(null);
  const [del, setDel] = useState<null | { kind: "menu" | "sub"; name: string }>(null);

  return (
    <>
      <PageHeader title="Analítica" eyebrow="Menús y submenús BI"
        description="Administra los menús analíticos y los submenús con enlaces a los tableros BI."
        actions={<BrandButton onClick={() => tab === "menu" ? setMenuModal({ mode: "add" }) : setSubModal({ mode: "add" })}>
          <Plus className="w-4 h-4" /> Agregar
        </BrandButton>} />

      <div className="flex gap-2 mb-6 border-b border-[color:var(--brand-line)]">
        <TabLink to="#menu" active={tab === "menu"} icon={<MenuIcon className="w-4 h-4" />}>Menú</TabLink>
        <TabLink to="#submenu" active={tab === "submenu"} icon={<ListTree className="w-4 h-4" />}>Submenú</TabLink>
      </div>

      {tab === "menu" ? (
        <Panel title="Menús de analítica">
          <BrandTable headers={["Menú", "Imagen", "Estado", "Acciones"]}
            rows={MENUS.map((m) => [
              <b key="n" className="text-[color:var(--brand-navy)]">{m.name}</b>,
              <span key="i" className="inline-flex items-center gap-1.5 text-[12.5px] text-[color:var(--brand-cyan)]"><ImageIcon className="w-3.5 h-3.5" />{m.img}</span>,
              <Chip key="s" color={m.activo ? "green" : "red"}>{m.activo ? "Activo" : "Inactivo"}</Chip>,
              <div key="a" className="flex gap-1">
                <button onClick={() => setMenuModal({ mode: "edit", row: m })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel({ kind: "menu", name: m.name })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
              </div>,
            ])} />
        </Panel>
      ) : (
        <Panel title="Submenús — enlaces BI">
          <BrandTable headers={["Menú", "Submenú", "Ruta BI", "Link video", "Link PDF", "Imagen", "Estado", "Acciones"]}
            rows={SUBMENUS.map((s) => [
              s.menu,
              <b key="n" className="text-[color:var(--brand-navy)]">{s.sub}</b>,
              <span key="r" className="inline-flex items-center gap-1.5 text-[12.5px] text-[color:var(--brand-cyan)]"><ExternalLink className="w-3.5 h-3.5" />{s.ruta}</span>,
              <span key="v" className="text-[12.5px] text-muted-foreground truncate max-w-[140px] inline-block">{s.video || "—"}</span>,
              <span key="p" className="text-[12.5px] text-muted-foreground truncate max-w-[140px] inline-block">{s.pdf || "—"}</span>,
              <span key="i" className="text-[12.5px] text-[color:var(--brand-cyan)]">{s.img || "—"}</span>,
              <Chip key="st" color={s.activo ? "green" : "red"}>{s.activo ? "Activo" : "Inactivo"}</Chip>,
              <div key="a" className="flex gap-1">
                <button onClick={() => setSubModal({ mode: "edit", row: s })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel({ kind: "sub", name: s.sub })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
              </div>,
            ])} />
        </Panel>
      )}

      {menuModal && <MenuModal mode={menuModal.mode} row={menuModal.row} onClose={() => setMenuModal(null)} />}
      {subModal && <SubModal mode={subModal.mode} row={subModal.row} onClose={() => setSubModal(null)} />}
      {del && <DeleteModal kind={del.kind} name={del.name} onClose={() => setDel(null)} />}
    </>
  );
}

const inputCls = "w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3";

function ModalShell({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-xl rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5" style={{ background: "linear-gradient(90deg,#C8102E,#F4B41A)" }} />
        <header className="flex items-center justify-between px-5 py-4 border-b border-[color:var(--brand-line)]">
          <h3 className="text-[18px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>{title}</h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)]"><X className="w-4 h-4" /></button>
        </header>
        {children}
      </div>
    </div>
  );
}

function MenuModal({ mode, row, onClose }: { mode: "add" | "edit"; row?: typeof MENUS[number]; onClose: () => void }) {
  return (
    <ModalShell title={mode === "add" ? "Nuevo menú" : "Editar menú"} onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 space-y-4">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Menú <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required maxLength={2000} defaultValue={row?.name} className={"mt-1 " + inputCls} />
        </label>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Imagen <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required={mode === "add"} type="file" accept="image/*" className="mt-1 w-full text-[13px] file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-[color:var(--brand-navy)] file:text-white file:cursor-pointer" />
        </label>
        <label className="flex items-center gap-3 rounded-lg border-2 border-[color:var(--brand-line)] px-3 h-11">
          <input type="checkbox" defaultChecked={mode === "add" ? true : row?.activo} className="w-4 h-4 accent-[color:var(--brand-red)]" />
          <span className="text-[13px] font-semibold text-[color:var(--brand-navy)]">¿Está activo?</span>
        </label>
        <footer className="flex justify-end gap-2 pt-2">
          <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
          <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
        </footer>
      </form>
    </ModalShell>
  );
}

function SubModal({ mode, row, onClose }: { mode: "add" | "edit"; row?: typeof SUBMENUS[number]; onClose: () => void }) {
  return (
    <ModalShell title={mode === "add" ? "Nuevo submenú" : "Editar submenú"} onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Menú <span className="text-[color:var(--brand-red)]">*</span></span>
          <select required defaultValue={row?.menu} className={"mt-1 bg-white " + inputCls}>
            <option value="">Seleccione…</option>
            {MENUS.map((m) => <option key={m.id}>{m.name}</option>)}
          </select>
        </label>
        {[
          { label: "Submenú", value: row?.sub, name: "sub", required: true },
          { label: "Ruta BI", value: row?.ruta, name: "ruta", required: true },
          { label: "Link video", value: row?.video, name: "video", required: true },
          { label: "Link PDF", value: row?.pdf, name: "pdf", required: true },
        ].map((f) => (
          <label key={f.name} className="block">
            <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>{f.label} {f.required && <span className="text-[color:var(--brand-red)]">*</span>}</span>
            <input required={f.required} maxLength={2000} defaultValue={f.value} className={"mt-1 " + inputCls} />
          </label>
        ))}
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Imagen (opcional)</span>
          <input type="file" accept="image/*" className="mt-1 w-full text-[13px] file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-[color:var(--brand-navy)] file:text-white file:cursor-pointer" />
        </label>
        <label className="flex items-center gap-3 rounded-lg border-2 border-[color:var(--brand-line)] px-3 h-11">
          <input type="checkbox" defaultChecked={row?.activo ?? true} className="w-4 h-4 accent-[color:var(--brand-red)]" />
          <span className="text-[13px] font-semibold text-[color:var(--brand-navy)]">Estado (activo)</span>
        </label>
        <footer className="flex justify-end gap-2 pt-2">
          <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
          <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
        </footer>
      </form>
    </ModalShell>
  );
}

function DeleteModal({ kind, name, onClose }: { kind: "menu" | "sub"; name: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-md rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5 bg-[color:var(--brand-red)]" />
        <div className="p-6 text-center">
          <div className="w-14 h-14 rounded-full grid place-items-center mx-auto mb-3 bg-[#fdecec] text-[color:var(--brand-red)]"><Trash2 className="w-6 h-6" /></div>
          <h3 className="text-[20px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>Eliminar {kind === "menu" ? "menú" : "submenú"}</h3>
          <p className="mt-2 text-[13.5px] text-muted-foreground">Se eliminará un {kind === "menu" ? "menú" : "submenú"}, ¿Está seguro?</p>
          <p className="mt-2 text-[13px] font-semibold text-[color:var(--brand-navy)]">{name}</p>
          <div className="mt-5 flex justify-center gap-2">
            <BrandButton variant="outline" onClick={onClose}>Cancelar</BrandButton>
            <BrandButton onClick={onClose}>Eliminar</BrandButton>
          </div>
        </div>
      </div>
    </div>
  );
}
