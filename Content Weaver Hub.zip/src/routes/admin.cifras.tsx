import { createFileRoute } from "@tanstack/react-router";
import { Send, Heart, AlertTriangle, Skull, MessageSquare } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/cifras")({ component: Cifras });

const NUMS = [
  { name: "lesionados", label: "Lesionados", value: "12908", color: "#F4B41A", icon: Heart },
  { name: "accidentados", label: "Accidentados", value: "47812", color: "#1597B8", icon: AlertTriangle },
  { name: "fallecidos", label: "Fallecidos", value: "3245", color: "#C8102E", icon: Skull },
];

function Cifras() {
  return (
    <>
      <PageHeader title="Cifras" eyebrow="Indicadores de la portada"
        description="Actualiza las cifras y mensajes que se muestran en la página principal del Portal ONSV." />
      <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
        <Panel title="Cifras numéricas">
          <div className="grid sm:grid-cols-3 gap-4">
            {NUMS.map((f) => (
              <div key={f.name} className="rounded-xl border-2 border-[color:var(--brand-line)] p-4" style={{ borderLeft: `5px solid ${f.color}` }}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-9 h-9 rounded-lg grid place-items-center" style={{ background: `color-mix(in srgb, ${f.color} 12%, #fff)`, color: f.color }}>
                    <f.icon className="w-4 h-4" />
                  </div>
                  <label className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>
                    {f.label} <span className="text-[color:var(--brand-red)]">*</span>
                  </label>
                </div>
                <input name={f.name} type="number" min={0} step={1} required defaultValue={f.value} pattern="\d+"
                  className="w-full h-12 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3 text-[24px] font-extrabold text-[color:var(--brand-navy)]"
                  style={{ fontFamily: "var(--font-display)" }} />
                <span className="text-[10.5px] text-muted-foreground mt-1 inline-block">Solo números enteros</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Mensajes del bloque de cifras">
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              { name: "mensaje1", label: "1° Mensaje", value: "Cada cifra representa una vida." },
              { name: "mensaje2", label: "2° Mensaje", value: "Trabajemos juntos para reducirlas." },
            ].map((m) => (
              <label key={m.name} className="block">
                <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold flex items-center gap-1.5" style={{ fontFamily: "var(--font-cond)" }}>
                  <MessageSquare className="w-3.5 h-3.5" /> {m.label} <span className="text-[color:var(--brand-red)]">*</span>
                </span>
                <input name={m.name} required maxLength={200} defaultValue={m.value}
                  className="mt-1 w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3 text-[14.5px]" />
                <span className="text-[10.5px] text-muted-foreground mt-1 inline-block">Máx. 200 caracteres</span>
              </label>
            ))}
          </div>
        </Panel>

        <div className="flex justify-end">
          <BrandButton type="submit"><Send className="w-4 h-4" /> Enviar Información</BrandButton>
        </div>
      </form>
    </>
  );
}
