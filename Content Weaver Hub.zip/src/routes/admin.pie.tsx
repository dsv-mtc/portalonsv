import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Send, MapPin, Phone, Mail, AlignLeft, Plus, Trash2, Link2, Facebook, Twitter, Instagram, Youtube, Linkedin } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton, Chip } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/pie")({ component: PiePagina });

function Field({ label, value, icon, required, maxLength = 200, type = "text", pattern }: { label: string; value: string; icon?: React.ReactNode; required?: boolean; maxLength?: number; type?: string; pattern?: string }) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>
        {label} {required && <span className="text-[color:var(--brand-red)]">*</span>}
      </span>
      <div className="mt-1 flex items-center gap-2 rounded-lg border-2 border-[color:var(--brand-line)] focus-within:border-[color:var(--brand-navy)] transition bg-white h-11 px-3">
        {icon}
        <input type={type} defaultValue={value} maxLength={maxLength} pattern={pattern} required={required} className="flex-1 bg-transparent outline-none text-[14.5px]" />
      </div>
      <span className="text-[10.5px] text-muted-foreground mt-1 inline-block">Máx. {maxLength} caracteres</span>
    </label>
  );
}

function PiePagina() {
  type Social = { id: number; red: string; url: string };
  const [socials, setSocials] = useState<Social[]>([
    { id: 1, red: "Facebook", url: "https://facebook.com/onsvperu" },
    { id: 2, red: "Twitter", url: "https://twitter.com/onsvperu" },
    { id: 3, red: "Instagram", url: "https://instagram.com/onsvperu" },
    { id: 4, red: "YouTube", url: "https://youtube.com/@onsvperu" },
  ]);
  const [nuevaRed, setNuevaRed] = useState("Facebook");
  const [nuevaUrl, setNuevaUrl] = useState("");

  const iconOf = (r: string) => {
    const c = "w-4 h-4";
    if (r === "Facebook") return <Facebook className={c} />;
    if (r === "Twitter") return <Twitter className={c} />;
    if (r === "Instagram") return <Instagram className={c} />;
    if (r === "YouTube") return <Youtube className={c} />;
    if (r === "LinkedIn") return <Linkedin className={c} />;
    return <Link2 className={c} />;
  };

  const addSocial = () => {
    if (!nuevaUrl.trim()) return;
    setSocials((s) => [...s, { id: Date.now(), red: nuevaRed, url: nuevaUrl.trim() }]);
    setNuevaUrl("");
  };

  return (
    <>
      <PageHeader
        title="Pie de página"
        eyebrow="Configuracion del sitio"
        description="Actualiza la información que aparece en el pie de página del portal público."
      />
      <form onSubmit={(e) => e.preventDefault()}>
        <Panel title="Información del pie de página">
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Número de teléfono" value="+51 (01) 615 7800" required pattern="[0-9+\-\s]+" icon={<Phone className="w-4 h-4 text-[color:var(--brand-red)]" />} />
            <Field label="Dirección" value="Jirón Zorritos 1203, Cercado de Lima" required icon={<MapPin className="w-4 h-4 text-[color:var(--brand-red)]" />} />
            <Field label="Correo" value="onsv@mtc.gob.pe" required type="email" icon={<Mail className="w-4 h-4 text-[color:var(--brand-red)]" />} />
            <Field label="Pie de página" value="© Observatorio Nacional de Seguridad Vial" required icon={<AlignLeft className="w-4 h-4 text-[color:var(--brand-red)]" />} />
          </div>
          <div className="mt-6 flex justify-end">
            <BrandButton type="submit"><Send className="w-4 h-4" /> Enviar Información</BrandButton>
          </div>
        </Panel>
      </form>

      <div className="h-6" />

      <Panel
        title="Redes sociales"
        actions={<Chip color="cyan">{socials.length} vinculadas</Chip>}
      >
        <p className="text-[13px] text-muted-foreground -mt-1 mb-4">
          Estas redes se muestran en el pie de página del portal. Puedes agregar, editar o eliminar.
        </p>

        <div className="grid md:grid-cols-[180px_1fr_auto] gap-3 items-end mb-5 p-4 rounded-xl border-2 border-dashed border-[color:var(--brand-line)] bg-[color:var(--brand-mist)]/40">
          <label className="block">
            <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Red</span>
            <select
              value={nuevaRed}
              onChange={(e) => setNuevaRed(e.target.value)}
              className="mt-1 w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] bg-white px-3 text-[14px] outline-none"
            >
              {["Facebook", "Twitter", "Instagram", "YouTube", "LinkedIn", "TikTok", "Otro"].map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>URL</span>
            <div className="mt-1 flex items-center gap-2 rounded-lg border-2 border-[color:var(--brand-line)] focus-within:border-[color:var(--brand-navy)] bg-white h-11 px-3">
              <Link2 className="w-4 h-4 text-[color:var(--brand-red)]" />
              <input
                type="url"
                placeholder="https://…"
                value={nuevaUrl}
                onChange={(e) => setNuevaUrl(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[14.5px]"
              />
            </div>
          </label>
          <BrandButton type="button" onClick={addSocial}>
            <Plus className="w-4 h-4" /> Agregar
          </BrandButton>
        </div>

        <ul className="space-y-2">
          {socials.map((s) => (
            <li
              key={s.id}
              className="grid grid-cols-[auto_160px_1fr_auto] gap-3 items-center rounded-lg border border-[color:var(--brand-line)] bg-white px-3 py-2 hover:border-[color:var(--brand-navy)]/40 transition"
            >
              <div className="w-9 h-9 rounded-lg grid place-items-center bg-[color:var(--brand-navy)] text-white">
                {iconOf(s.red)}
              </div>
              <select
                value={s.red}
                onChange={(e) => setSocials((arr) => arr.map((x) => x.id === s.id ? { ...x, red: e.target.value } : x))}
                className="h-10 rounded-md border border-[color:var(--brand-line)] bg-white px-2 text-[13.5px] font-bold text-[color:var(--brand-navy)] outline-none focus:border-[color:var(--brand-navy)]"
                style={{ fontFamily: "var(--font-cond)" }}
              >
                {["Facebook", "Twitter", "Instagram", "YouTube", "LinkedIn", "TikTok", "Otro"].map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
              <input
                type="url"
                value={s.url}
                onChange={(e) => setSocials((arr) => arr.map((x) => x.id === s.id ? { ...x, url: e.target.value } : x))}
                className="h-10 rounded-md border border-[color:var(--brand-line)] bg-white px-3 text-[13.5px] outline-none focus:border-[color:var(--brand-navy)]"
              />
              <button
                type="button"
                onClick={() => setSocials((arr) => arr.filter((x) => x.id !== s.id))}
                className="w-10 h-10 rounded-md grid place-items-center text-[color:var(--brand-red)] hover:bg-[color:var(--brand-red)] hover:text-white border border-[color:var(--brand-line)] transition"
                aria-label="Eliminar red social"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </li>
          ))}
          {socials.length === 0 && (
            <li className="text-center py-8 text-muted-foreground text-[13px]">
              Aún no hay redes sociales configuradas.
            </li>
          )}
        </ul>

        <div className="mt-6 flex justify-end">
          <BrandButton type="button"><Send className="w-4 h-4" /> Guardar redes</BrandButton>
        </div>
      </Panel>
    </>
  );
}