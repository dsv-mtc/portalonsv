import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff, ShieldCheck, ArrowRight, Lock } from "lucide-react";
import { OnsvLogo } from "@/components/onsv-logo";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Iniciar sesión — Panel ONSV" },
      { name: "description", content: "Acceso al panel administrativo del Observatorio Nacional de Seguridad Vial." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [email, setEmail] = useState("admin@onsv.gob.pe");
  const [pass, setPass] = useState("");

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    navigate({ to: "/admin" });
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-[1.05fr_1fr] bg-white">
      <div
        className="relative hidden lg:flex flex-col justify-between p-10 overflow-hidden text-white"
        style={{ background: "linear-gradient(160deg,#0d1730 0%,#14213D 55%,#1F3864 100%)" }}
      >
        <div
          aria-hidden
          className="absolute inset-x-0 top-0 h-8"
          style={{ background: "repeating-linear-gradient(45deg,#101a34,#101a34 14px,#16223f 14px,#16223f 28px)" }}
        />
        <div aria-hidden className="absolute -right-24 -top-24 w-[420px] h-[420px] rounded-full opacity-20 blur-3xl" style={{ background: "radial-gradient(circle, #F4B41A 0%, transparent 60%)" }} />
        <div aria-hidden className="absolute -left-32 bottom-0 w-[420px] h-[420px] rounded-full opacity-30 blur-3xl" style={{ background: "radial-gradient(circle, #C8102E 0%, transparent 55%)" }} />

        <div className="relative z-10 flex items-center gap-4 mt-6">
          <OnsvLogo className="w-14 h-14" />
          <div className="leading-none">
            <div className="text-[22px] font-extrabold uppercase tracking-tight" style={{ fontFamily: "var(--font-display)" }}>Observatorio Nacional</div>
            <div className="text-[11px] font-bold tracking-[0.2em] uppercase mt-1 text-[color:var(--brand-amber)]" style={{ fontFamily: "var(--font-cond)" }}>de Seguridad Vial · MTC</div>
          </div>
        </div>

        <div className="relative z-10 max-w-md">
          <span className="inline-block px-3 py-1 mb-6 text-[11px] uppercase tracking-[0.16em] font-bold rounded" style={{ background: "#C8102E", color: "#fff", fontFamily: "var(--font-cond)" }}>Panel Administrativo</span>
          <h1 className="text-[clamp(36px,4.5vw,56px)] leading-[0.98] uppercase text-white" style={{ fontFamily: "var(--font-display)", fontWeight: 800 }}>
            Bienvenido de nuevo, <em className="not-italic text-[color:var(--brand-amber)]">administrador</em>.
          </h1>
          <p className="mt-5 text-[15px] text-white/70 max-w-sm">Gestiona cifras, regiones, comunicaciones, analítica y datos abiertos del Portal ONSV desde un solo lugar.</p>

          <div className="mt-10 grid grid-cols-3 gap-3">
            {[{ k: "Cifras", v: "24" }, { k: "Datasets", v: "148" }, { k: "Eventos", v: "36" }].map((s) => (
              <div key={s.k} className="relative rounded-xl p-3 bg-white/[0.04] border border-white/10 backdrop-blur">
                <span aria-hidden className="absolute left-0 top-2 bottom-2 w-[3px] rounded-full bg-[color:var(--brand-amber)]" />
                <div className="text-[26px] font-extrabold leading-none text-white" style={{ fontFamily: "var(--font-display)" }}>{s.v}</div>
                <div className="text-[10px] font-bold uppercase tracking-[0.1em] mt-1 text-white/60" style={{ fontFamily: "var(--font-cond)" }}>{s.k}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10 flex items-center gap-3 text-[11px] uppercase tracking-[0.14em] text-white/50" style={{ fontFamily: "var(--font-cond)" }}>
          <ShieldCheck className="w-4 h-4 text-[color:var(--brand-amber)]" />
          Conexión cifrada · Acceso restringido
        </div>
      </div>

      <div className="flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <OnsvLogo className="w-12 h-12" tone="dark" />
            <div className="text-[color:var(--brand-navy)]">
              <div className="text-[18px] font-extrabold uppercase tracking-tight" style={{ fontFamily: "var(--font-display)" }}>Portal ONSV</div>
              <div className="text-[10px] font-bold tracking-[0.18em] uppercase text-[color:var(--brand-red)]" style={{ fontFamily: "var(--font-cond)" }}>Panel administrativo</div>
            </div>
          </div>

          <span className="onsv-eyebrow">Autenticación</span>
          <h2 className="mt-2 text-[clamp(30px,3.4vw,42px)] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 800, lineHeight: 1 }}>Iniciar sesión</h2>
          <p className="mt-3 text-sm text-muted-foreground">Ingresa tus credenciales institucionales para acceder al panel.</p>

          <form onSubmit={onSubmit} className="mt-8 space-y-5">
            <FloatingField id="email" label="Correo institucional" type="email" value={email} onChange={setEmail} required />
            <FloatingField
              id="password"
              label="Contraseña"
              type={show ? "text" : "password"}
              value={pass}
              onChange={setPass}
              required
              trailing={
                <button type="button" onClick={() => setShow((s) => !s)} className="text-muted-foreground hover:text-[color:var(--brand-red)] transition" aria-label="Mostrar u ocultar contraseña">
                  {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
            />

            <div className="flex items-center justify-between text-[13px]">
              <label className="flex items-center gap-2 text-muted-foreground cursor-pointer select-none">
                <input type="checkbox" className="accent-[color:var(--brand-red)] w-4 h-4" />
                Mantener sesión iniciada
              </label>
              <Link to="/auth" className="font-bold uppercase tracking-wider text-[11px] text-[color:var(--brand-red)] hover:text-[color:var(--brand-red-dark)]" style={{ fontFamily: "var(--font-cond)" }}>
                ¿Olvidaste tu contraseña?
              </Link>
            </div>

            <button
              type="submit"
              className="group w-full flex items-center justify-center gap-2 rounded-lg h-12 bg-[color:var(--brand-red)] hover:bg-[color:var(--brand-red-dark)] text-white uppercase tracking-[0.06em] font-bold text-[14px] transition shadow-[0_10px_28px_-10px_rgba(200,16,46,0.6)]"
              style={{ fontFamily: "var(--font-cond)" }}
            >
              <Lock className="w-4 h-4" />
              Ingresar al panel
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-[color:var(--brand-line)] text-[11px] uppercase tracking-[0.14em] text-muted-foreground flex items-center gap-2" style={{ fontFamily: "var(--font-cond)" }}>
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[color:var(--brand-red)]" />
            Ministerio de Transportes y Comunicaciones
          </div>
        </div>
      </div>
    </div>
  );
}

function FloatingField({
  id, label, type, value, onChange, required, trailing,
}: {
  id: string; label: string; type: string; value: string; onChange: (v: string) => void; required?: boolean; trailing?: React.ReactNode;
}) {
  return (
    <div className="relative">
      <input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        placeholder=" "
        className="peer w-full h-14 rounded-xl border-2 border-[color:var(--brand-line)] bg-white px-4 pt-5 pb-1 pr-11 text-[15px] outline-none transition focus:border-[color:var(--brand-navy)]"
      />
      <label
        htmlFor={id}
        className="absolute left-3 top-1/2 -translate-y-1/2 px-1 bg-white text-muted-foreground text-[14px] transition-all pointer-events-none peer-focus:top-2 peer-focus:translate-y-0 peer-focus:text-[11px] peer-focus:text-[color:var(--brand-navy)] peer-focus:font-bold peer-focus:uppercase peer-focus:tracking-wider peer-[:not(:placeholder-shown)]:top-2 peer-[:not(:placeholder-shown)]:translate-y-0 peer-[:not(:placeholder-shown)]:text-[11px] peer-[:not(:placeholder-shown)]:text-[color:var(--brand-navy)] peer-[:not(:placeholder-shown)]:font-bold peer-[:not(:placeholder-shown)]:uppercase peer-[:not(:placeholder-shown)]:tracking-wider"
        style={{ fontFamily: "var(--font-cond)" }}
      >
        {label}
      </label>
      {trailing && <div className="absolute right-3 top-1/2 -translate-y-1/2">{trailing}</div>}
    </div>
  );
}