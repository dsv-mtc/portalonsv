import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Send, X, Link as LinkIcon, ImageIcon } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton, Chip } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/popup")({ component: Popup });

function Popup() {
  const [active, setActive] = useState(true);
  const [enlace, setEnlace] = useState("https://onsv.gob.pe/semana-seguridad-vial");
  return (
    <>
      <PageHeader title="Popup" eyebrow="Aviso emergente del portal"
        description="Configura la imagen y enlace del popup que aparece al ingresar al Portal ONSV." />
      <form onSubmit={(e) => e.preventDefault()}>
        <div className="grid lg:grid-cols-2 gap-6">
          <Panel title="Configuración del popup">
            <label className="block mb-4">
              <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>
                Enlace <span className="text-[color:var(--brand-red)]">*</span>
              </span>
              <div className="mt-1 flex items-center gap-2 rounded-lg border-2 border-[color:var(--brand-line)] focus-within:border-[color:var(--brand-navy)] transition bg-white h-11 px-3">
                <LinkIcon className="w-4 h-4 text-[color:var(--brand-red)]" />
                <input required maxLength={300} value={enlace} onChange={(e) => setEnlace(e.target.value)} className="flex-1 bg-transparent outline-none text-[14.5px]" />
              </div>
              <span className="text-[10.5px] text-muted-foreground mt-1 inline-block">Máx. 300 caracteres</span>
            </label>

            <label className="block mb-4">
              <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>
                Imagen <span className="text-[color:var(--brand-red)]">*</span>
              </span>
              <input required type="file" accept="image/png,image/jpeg" className="mt-1 w-full text-[13px] file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-[color:var(--brand-navy)] file:text-white file:cursor-pointer" />
              <span className="text-[10.5px] text-muted-foreground mt-1 inline-block">Formatos aceptados: PNG o JPG</span>
            </label>

            <div className="flex items-center justify-between rounded-xl bg-[color:var(--brand-mist)] p-3 mb-5">
              <div>
                <div className="text-[13px] font-bold uppercase tracking-wide text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-cond)" }}>Estado</div>
                <p className="text-[12.5px] text-muted-foreground">Activa o desactiva el popup en el portal.</p>
              </div>
              <button type="button" onClick={() => setActive((v) => !v)} className={"relative w-14 h-8 rounded-full transition " + (active ? "bg-[color:var(--brand-red)]" : "bg-slate-300")} aria-pressed={active}>
                <span className={"absolute top-1 w-6 h-6 rounded-full bg-white shadow transition-all " + (active ? "left-7" : "left-1")} />
              </button>
            </div>

            <div className="flex justify-end">
              <BrandButton type="submit"><Send className="w-4 h-4" /> Enviar</BrandButton>
            </div>
          </Panel>

          <Panel title="Vista previa" actions={<Chip color={active ? "green" : "red"}>{active ? "Activo" : "Inactivo"}</Chip>}>
            <div className="rounded-xl bg-[color:var(--brand-mist)] p-8 flex items-center justify-center min-h-[380px]">
              <div className="relative w-full max-w-sm rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden">
                <div className="h-2" style={{ background: "linear-gradient(90deg,#C8102E,#F4B41A)" }} />
                <button type="button" className="absolute top-3 right-3 w-7 h-7 rounded-full bg-[color:var(--brand-mist)] grid place-items-center text-[color:var(--brand-navy)]"><X className="w-4 h-4" /></button>
                <div className="aspect-[4/5] bg-gradient-to-br from-[color:var(--brand-mist)] to-white grid place-items-center">
                  <div className="text-center text-muted-foreground">
                    <ImageIcon className="w-10 h-10 mx-auto mb-2 opacity-50" />
                    <p className="text-[12px] uppercase tracking-wider font-bold" style={{ fontFamily: "var(--font-cond)" }}>Imagen del popup</p>
                    <p className="text-[11px] mt-1 max-w-[220px] truncate">{enlace}</p>
                  </div>
                </div>
              </div>
            </div>
          </Panel>
        </div>
      </form>
    </>
  );
}
