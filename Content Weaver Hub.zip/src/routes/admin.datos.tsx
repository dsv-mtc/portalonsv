import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Pencil, Trash2, Database, Tag, Layers, Search, RotateCcw, X, Save, FileSpreadsheet, FileText, FileType2, Image as ImageIcon } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Panel, BrandButton, Chip, BrandTable } from "@/components/ui-bits";

export const Route = createFileRoute("/admin/datos")({ component: Datos });

const CATEGORIAS = ["Accidentes", "Fiscalización", "Educación", "Infraestructura", "Licencias"];
const TIPOS_CONTENIDO = ["Estadística", "Informe", "Investigación", "Mapa", "Manual"];

const DATASETS = [
  { titulo: "Siniestros por región 2020-2024", autor: "ONSV", desc: "Serie histórica de siniestros.", cat: "Accidentes", tipo: "Estadística", xls: "acc.xlsx", pdf: "", csv: "acc.csv", fecha: "2025-05-12" },
  { titulo: "Operativos de fiscalización 2024", autor: "SUTRAN", desc: "Reporte de operativos.", cat: "Fiscalización", tipo: "Informe", xls: "", pdf: "op.pdf", csv: "op.csv", fecha: "2025-04-02" },
  { titulo: "Escolares capacitados por región", autor: "MINEDU", desc: "Programa Escolares Seguros.", cat: "Educación", tipo: "Estadística", xls: "esc.xlsx", pdf: "", csv: "", fecha: "2025-02-18" },
];
const CATS = [
  { name: "Accidentes", icon: "acc.png", activo: true, color: "#C8102E" },
  { name: "Fiscalización", icon: "fis.png", activo: true, color: "#14213D" },
  { name: "Educación", icon: "edu.png", activo: true, color: "#F4B41A" },
  { name: "Infraestructura", icon: "inf.png", activo: false, color: "#1597B8" },
];
const TIPOS = [
  { name: "Estadística", activo: true },
  { name: "Informe", activo: true },
  { name: "Investigación", activo: true },
  { name: "Mapa", activo: false },
];

type Ds = (typeof DATASETS)[number];
type Cat = (typeof CATS)[number];
type Tp = (typeof TIPOS)[number];

function TabLink({ to, active, children, icon }: { to: string; active: boolean; children: React.ReactNode; icon: React.ReactNode }) {
  return <a href={to} className={"px-4 h-11 -mb-px inline-flex items-center gap-2 text-[13px] uppercase font-bold tracking-wider transition font-[family-name:var(--font-cond)] " + (active ? "text-[color:var(--brand-red)] border-b-2 border-[color:var(--brand-red)]" : "text-muted-foreground hover:text-[color:var(--brand-navy)] border-b-2 border-transparent")}>{icon}{children}</a>;
}
function FileTag({ label, color, has }: { label: string; color: string; has: boolean }) {
  if (!has) return <span className="text-muted-foreground text-[12px]">—</span>;
  return <span className="text-[10px] font-extrabold uppercase tracking-wider px-1.5 py-0.5 rounded" style={{ background: `color-mix(in srgb, ${color} 12%, #fff)`, color, fontFamily: "var(--font-cond)" }}>{label}</span>;
}
const inputCls = "w-full h-11 rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3";

function Datos() {
  const hash = useRouterState({ select: (s) => s.location.hash });
  const tab = hash === "categorias" ? "categorias" : hash === "tipo" ? "tipo" : "datos";

  const [dsModal, setDsModal] = useState<null | { mode: "add" | "edit"; row?: Ds }>(null);
  const [catModal, setCatModal] = useState<null | { mode: "add" | "edit"; row?: Cat }>(null);
  const [tipoModal, setTipoModal] = useState<null | { mode: "add" | "edit"; row?: Tp }>(null);
  const [del, setDel] = useState<null | string>(null);

  const onAdd = () => {
    if (tab === "datos") setDsModal({ mode: "add" });
    else if (tab === "categorias") setCatModal({ mode: "add" });
    else setTipoModal({ mode: "add" });
  };

  return (
    <>
      <PageHeader title="Datos Abiertos" eyebrow="Datos · Categorías · Tipos"
        description="Publica datasets, define categorías temáticas y tipos de contenido aceptados."
        actions={<BrandButton onClick={onAdd}><Plus className="w-4 h-4" /> Agregar</BrandButton>} />

      <div className="flex gap-2 mb-6 border-b border-[color:var(--brand-line)]">
        <TabLink to="#datos" active={tab === "datos"} icon={<Database className="w-4 h-4" />}>Datos</TabLink>
        <TabLink to="#categorias" active={tab === "categorias"} icon={<Tag className="w-4 h-4" />}>Categorías</TabLink>
        <TabLink to="#tipo" active={tab === "tipo"} icon={<Layers className="w-4 h-4" />}>Tipos</TabLink>
      </div>

      {tab === "datos" && (
        <>
          <Panel title="Filtros" className="mb-6">
            <div className="grid md:grid-cols-4 gap-3 items-end">
              <FilterInput label="Título" placeholder="Buscar por título…" />
              <FilterInput label="Descripción" placeholder="Buscar por descripción…" />
              <FilterSelect label="Categoría" options={["Todas", ...CATEGORIAS]} />
              <FilterInput label="Fecha" type="date" />
              <div className="md:col-span-4 flex gap-2">
                <BrandButton><Search className="w-4 h-4" /> Consultar</BrandButton>
                <BrandButton variant="outline"><RotateCcw className="w-4 h-4" /> Limpiar</BrandButton>
              </div>
            </div>
          </Panel>

          <Panel title="Datasets publicados">
            <BrandTable headers={["Título", "Autor", "Descripción", "Categoría", "Tipo", "Excel", "PDF", "CSV", "Fecha", "Acciones"]}
              rows={DATASETS.map((d) => [
                <b key="n" className="text-[color:var(--brand-navy)]">{d.titulo}</b>,
                d.autor,
                <span key="ds" className="text-[12.5px] text-muted-foreground line-clamp-2 max-w-[180px] inline-block">{d.desc}</span>,
                <Chip key="c" color="cyan">{d.cat}</Chip>,
                <Chip key="t" color="amber">{d.tipo}</Chip>,
                <FileTag key="x" label="XLS" color="#1f7a44" has={!!d.xls} />,
                <FileTag key="p" label="PDF" color="#C8102E" has={!!d.pdf} />,
                <FileTag key="cs" label="CSV" color="#1E5BAA" has={!!d.csv} />,
                d.fecha,
                <div key="a" className="flex gap-1">
                  <button onClick={() => setDsModal({ mode: "edit", row: d })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => setDel(d.titulo)} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
                </div>,
              ])} />
          </Panel>
        </>
      )}

      {tab === "categorias" && (
        <Panel title="Categorías">
          <BrandTable headers={["Categoría", "Ícono", "Estado", "Acciones"]}
            rows={CATS.map((c) => [
              <div key="n" className="flex items-center gap-2"><Tag className="w-4 h-4" style={{ color: c.color }} /><b className="text-[color:var(--brand-navy)]">{c.name}</b></div>,
              <span key="i" className="inline-flex items-center gap-1.5 text-[12.5px] text-[color:var(--brand-cyan)]"><ImageIcon className="w-3.5 h-3.5" />{c.icon}</span>,
              <Chip key="s" color={c.activo ? "green" : "red"}>{c.activo ? "Activo" : "Inactivo"}</Chip>,
              <div key="a" className="flex gap-1">
                <button onClick={() => setCatModal({ mode: "edit", row: c })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel(c.name)} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
              </div>,
            ])} />
        </Panel>
      )}

      {tab === "tipo" && (
        <Panel title="Tipos de contenido">
          <BrandTable headers={["Tipo", "Estado", "Acciones"]}
            rows={TIPOS.map((t) => [
              <b key="n" className="text-[color:var(--brand-navy)]">{t.name}</b>,
              <Chip key="s" color={t.activo ? "green" : "red"}>{t.activo ? "Activo" : "Inactivo"}</Chip>,
              <div key="a" className="flex gap-1">
                <button onClick={() => setTipoModal({ mode: "edit", row: t })} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-navy)]"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel(t.name)} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)] text-[color:var(--brand-red)]"><Trash2 className="w-4 h-4" /></button>
              </div>,
            ])} />
        </Panel>
      )}

      {dsModal && <DsModal mode={dsModal.mode} row={dsModal.row} onClose={() => setDsModal(null)} />}
      {catModal && <CatModal mode={catModal.mode} row={catModal.row} onClose={() => setCatModal(null)} />}
      {tipoModal && <TipoModal mode={tipoModal.mode} row={tipoModal.row} onClose={() => setTipoModal(null)} />}
      {del && <DeleteModal name={del} onClose={() => setDel(null)} />}
    </>
  );
}

function FilterInput({ label, ...rest }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>{label}</span>
      <input {...rest} className={"mt-1 " + inputCls} />
    </label>
  );
}
function FilterSelect({ label, options }: { label: string; options: string[] }) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>{label}</span>
      <select className={"mt-1 bg-white " + inputCls}>{options.map((o) => <option key={o}>{o}</option>)}</select>
    </label>
  );
}

function ModalShell({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className={"relative w-full rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden " + (wide ? "max-w-2xl" : "max-w-md")} onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5" style={{ background: "linear-gradient(90deg,#C8102E,#F4B41A)" }} />
        <header className="flex items-center justify-between px-5 py-4 border-b border-[color:var(--brand-line)]">
          <h3 className="text-[18px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>{title}</h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-[color:var(--brand-mist)]"><X className="w-4 h-4" /></button>
        </header>
        {children}
      </div>
    </div>
  );
}

function DsModal({ mode, row, onClose }: { mode: "add" | "edit"; row?: Ds; onClose: () => void }) {
  return (
    <ModalShell wide title={mode === "add" ? "Nuevo dataset" : "Editar dataset"} onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 max-h-[75vh] overflow-y-auto space-y-4">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Título <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required maxLength={2000} defaultValue={row?.titulo} className={"mt-1 " + inputCls} />
        </label>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Autor <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required maxLength={2000} defaultValue={row?.autor} className={"mt-1 " + inputCls} />
        </label>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Descripción <span className="text-[color:var(--brand-red)]">*</span></span>
          <textarea required maxLength={2000} defaultValue={row?.desc} className="mt-1 w-full min-h-[90px] rounded-lg border-2 border-[color:var(--brand-line)] focus:border-[color:var(--brand-navy)] outline-none px-3 py-2" />
        </label>
        <div className="grid sm:grid-cols-2 gap-4">
          <label className="block">
            <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Categoría <span className="text-[color:var(--brand-red)]">*</span></span>
            <select required defaultValue={row?.cat} className={"mt-1 bg-white " + inputCls}>
              <option value="">Seleccione…</option>
              {CATEGORIAS.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Tipo de contenido <span className="text-[color:var(--brand-red)]">*</span></span>
            <select required defaultValue={row?.tipo} className={"mt-1 bg-white " + inputCls}>
              <option value="">Seleccione…</option>
              {TIPOS_CONTENIDO.map((t) => <option key={t}>{t}</option>)}
            </select>
          </label>
        </div>
        <div className="grid sm:grid-cols-3 gap-3">
          <FileField label="Archivo Excel" accept=".xlsx" icon={<FileSpreadsheet className="w-4 h-4 text-[#1f7a44]" />} />
          <FileField label="Archivo PDF" accept="application/pdf" icon={<FileType2 className="w-4 h-4 text-[color:var(--brand-red)]" />} />
          <FileField label="Archivo CSV" accept=".csv" icon={<FileText className="w-4 h-4 text-[color:var(--brand-cyan)]" />} />
        </div>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Fecha <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required type="date" defaultValue={row?.fecha} className={"mt-1 " + inputCls} />
        </label>
        <footer className="flex justify-end gap-2 pt-2">
          <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
          <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
        </footer>
      </form>
    </ModalShell>
  );
}

function FileField({ label, accept, icon }: { label: string; accept: string; icon: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold flex items-center gap-1.5" style={{ fontFamily: "var(--font-cond)" }}>{icon}{label}</span>
      <input type="file" accept={accept} className="mt-1 w-full text-[12px] file:mr-2 file:px-2 file:py-1.5 file:rounded file:border-0 file:bg-[color:var(--brand-navy)] file:text-white file:cursor-pointer" />
    </label>
  );
}

function CatModal({ mode, row, onClose }: { mode: "add" | "edit"; row?: Cat; onClose: () => void }) {
  return (
    <ModalShell title={mode === "add" ? "Nueva categoría" : "Editar categoría"} onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 space-y-4">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Nombre <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required maxLength={2000} defaultValue={row?.name} className={"mt-1 " + inputCls} />
        </label>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Ícono <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required={mode === "add"} type="file" accept="image/*" className="mt-1 w-full text-[13px] file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-[color:var(--brand-navy)] file:text-white file:cursor-pointer" />
        </label>
        <label className="flex items-center gap-3 rounded-lg border-2 border-[color:var(--brand-line)] px-3 h-11">
          <input type="checkbox" defaultChecked={mode === "add" ? true : row?.activo} className="w-4 h-4 accent-[color:var(--brand-red)]" />
          <span className="text-[13px] font-semibold text-[color:var(--brand-navy)]">¿Está activo?</span>
        </label>
        <footer className="flex justify-end gap-2 pt-2">
          <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
          <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
        </footer>
      </form>
    </ModalShell>
  );
}

function TipoModal({ mode, row, onClose }: { mode: "add" | "edit"; row?: Tp; onClose: () => void }) {
  return (
    <ModalShell title={mode === "add" ? "Nuevo tipo" : "Editar tipo"} onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); onClose(); }} className="p-5 space-y-4">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.08em] text-[color:var(--brand-navy)] font-bold" style={{ fontFamily: "var(--font-cond)" }}>Nombre <span className="text-[color:var(--brand-red)]">*</span></span>
          <input required maxLength={2000} defaultValue={row?.name} className={"mt-1 " + inputCls} />
        </label>
        <label className="flex items-center gap-3 rounded-lg border-2 border-[color:var(--brand-line)] px-3 h-11">
          <input type="checkbox" defaultChecked={mode === "add" ? true : row?.activo} className="w-4 h-4 accent-[color:var(--brand-red)]" />
          <span className="text-[13px] font-semibold text-[color:var(--brand-navy)]">¿Está activo?</span>
        </label>
        <footer className="flex justify-end gap-2 pt-2">
          <BrandButton variant="outline" type="button" onClick={onClose}>Cancelar</BrandButton>
          <BrandButton type="submit"><Save className="w-4 h-4" /> Guardar</BrandButton>
        </footer>
      </form>
    </ModalShell>
  );
}

function DeleteModal({ name, onClose }: { name: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="relative w-full max-w-md rounded-2xl bg-white shadow-[var(--shadow-brand-lg)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5 bg-[color:var(--brand-red)]" />
        <div className="p-6 text-center">
          <div className="w-14 h-14 rounded-full grid place-items-center mx-auto mb-3 bg-[#fdecec] text-[color:var(--brand-red)]"><Trash2 className="w-6 h-6" /></div>
          <h3 className="text-[20px] uppercase text-[color:var(--brand-navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>Confirmar eliminación</h3>
          <p className="mt-2 text-[13.5px] text-muted-foreground">Se eliminará esta información, ¿Está seguro?</p>
          <p className="mt-2 text-[13px] font-semibold text-[color:var(--brand-navy)]">{name}</p>
          <div className="mt-5 flex justify-center gap-2">
            <BrandButton variant="outline" onClick={onClose}>Cancelar</BrandButton>
            <BrandButton onClick={onClose}>Eliminar</BrandButton>
          </div>
        </div>
      </div>
    </div>
  );
}
